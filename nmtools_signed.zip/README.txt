nms.cpp
nms.u16.cpp

to build run

c++ -O3 -Wall  nms.u16.cpp -o nms.u16 -lpng

c++ -O3 -Wall  nms.cpp -o nms -lpng
